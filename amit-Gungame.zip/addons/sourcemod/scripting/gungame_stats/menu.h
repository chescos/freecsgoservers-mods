new ClientOnPage[MAXPLAYERS + 1] = {0, ...};

