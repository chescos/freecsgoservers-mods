new g_tripleEffects[MAXPLAYERS+1] = {0, ...};
new g_Ent_Effect[MAXPLAYERS+1] = {-1, ...};
