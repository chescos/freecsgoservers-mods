/* Menus */
new ClientOnPage[MAXPLAYERS + 1];
new WeaponLevelPages;